﻿namespace Entities
{
    public class Entities
    {

    }
}