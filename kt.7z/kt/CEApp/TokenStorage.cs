﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CEApp
{
    public static class TokenStorage
    {
        public static string Key { get; set; }
    }
}
